@ stdcall ProcessPrng(ptr long)
